package com.example.omnia.sender23;

import android.os.AsyncTask;

import org.jivesoftware.smack.AbstractXMPPConnection;
import org.jivesoftware.smack.ConnectionConfiguration;
import org.jivesoftware.smack.SmackException;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.chat.Chat;
import org.jivesoftware.smack.chat.ChatManager;
import org.jivesoftware.smack.chat.ChatMessageListener;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.tcp.XMPPTCPConnection;
import org.jivesoftware.smack.tcp.XMPPTCPConnectionConfiguration;

import im.delight.android.location.SimpleLocation;

public class sdscclient extends AsyncTask<String, String, String> implements ChatMessageListener {
	AbstractXMPPConnection conn1;
    private SimpleLocation location;

    public sdscclient(SimpleLocation location) {
        this.location = location;
    }

    @Override
	protected String doInBackground(String... params) {
		// Create a connection to the jabber.org server.
		XMPPTCPConnectionConfiguration config = XMPPTCPConnectionConfiguration.builder()
				.setUsernameAndPassword("driver", "driver")
				.setHost("192.168.4.111")
				.setSecurityMode(ConnectionConfiguration.SecurityMode.disabled)
				.setServiceName("192.168.4.111")
				.setPort(5222)
				.setDebuggerEnabled(true) // to view what's happening in detail
				.build();

		conn1 = new XMPPTCPConnection(config);
		try {
			conn1.connect();
			if(conn1.isConnected()) {

			}
			conn1.login();

			if(conn1.isAuthenticated()) {

			}

			sendMessage(String.valueOf(location.getLatitude())+" "+String.valueOf(location.getLongitude()),"mrinal@mangodsip");


		}
		catch (Exception e) {

		}

		return "";
	}


	public void sendMessage(String message, String to) throws XMPPException, SmackException.NotConnectedException {
		ChatManager chatManager = ChatManager.getInstanceFor(conn1);
		Chat chat = chatManager.createChat(to,this); // pass XmppClient instance as listener for received messages.
		chat.sendMessage(message);
	}

	@Override
	protected void onPostExecute(String result) {
	}

	@Override
	public void processMessage(Chat chat, Message message) {

	}
}
