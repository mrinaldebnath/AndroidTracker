package com.example.omnia.passenger;

import android.os.AsyncTask;
import android.util.Log;

import org.jivesoftware.smack.AbstractXMPPConnection;
import org.jivesoftware.smack.ConnectionConfiguration;
import org.jivesoftware.smack.PacketCollector;
import org.jivesoftware.smack.chat.Chat;
import org.jivesoftware.smack.chat.ChatMessageListener;
import org.jivesoftware.smack.filter.AndFilter;
import org.jivesoftware.smack.filter.PacketTypeFilter;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Packet;
import org.jivesoftware.smack.tcp.XMPPTCPConnection;
import org.jivesoftware.smack.tcp.XMPPTCPConnectionConfiguration;

public class sdscclient extends AsyncTask<String, String, String> implements ChatMessageListener {
	AbstractXMPPConnection conn1;
    AndFilter filter;
    PacketCollector collector;
    public double latitude;
    public double longitude;
    MapsActivity main;


	public sdscclient(MapsActivity main) {
        this.main=main;
	}

	@Override
	protected String doInBackground(String... params) {

        // Create a connection to the jabber.org server.
        XMPPTCPConnectionConfiguration config = XMPPTCPConnectionConfiguration.builder()
                .setUsernameAndPassword("mrinal", "mrinal")
                .setHost("114.130.56.152")
                .setSecurityMode(ConnectionConfiguration.SecurityMode.disabled)
                .setServiceName("114.130.56.152")
                .setPort(5222)
                .setDebuggerEnabled(true) // to view what's happening in detail
                .build();

        conn1 = new XMPPTCPConnection(config);
        try {
            conn1.connect();
            if (conn1.isConnected()) {

            }
            conn1.login();

            if (conn1.isAuthenticated()) {

            }

            filter = new AndFilter(new PacketTypeFilter(Message.class));
            collector = conn1.createPacketCollector(filter);

        }
        catch (Exception e)
        {
            Log.v("msg",e.getMessage());
        }

        while(true)
        {
            Packet packet = collector.pollResult();

            //sendMessage(String.valueOf(location.getLatitude())+" "+String.valueOf(location.getLongitude()),"mrinal@mangodsip");
            if(packet!=null)
            {

                if (packet instanceof Message) {
                    Message message = (Message) packet;
                    if (message != null && message.getBody() != null ){



                    String[] messages=message.getBody().split(" ");

                    latitude=Double.parseDouble(messages[0]);
                    longitude=Double.parseDouble(messages[1]);

                        main.runOnUiThread(new Runnable() {

                            @Override
                            public void run() {
                                main.setMarker(latitude,longitude);
                            }

                        });

                    }

                }
            }
        }

	}

	@Override
	protected void onPostExecute(String result) {
	}

	@Override
	public void processMessage(Chat chat, Message message) {

	}
}
